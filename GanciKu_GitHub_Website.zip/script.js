const products=[
 {id:1,name:"Strawberry Pop",desc:"Acrylic • Cute",price:35000,cat:"cute",emoji:"🍓",badge:"BEST SELLER"},
 {id:2,name:"Mochi Bear",desc:"Soft PVC • Limited",price:42000,cat:"cute",emoji:"🐻",badge:"LIMITED"},
 {id:3,name:"Sakura Spirit",desc:"Acrylic • Anime",price:38000,cat:"anime",emoji:"🌸",badge:"NEW"},
 {id:4,name:"Lucky Frog",desc:"Rubber • Collectible",price:30000,cat:"cute",emoji:"🐸",badge:""},
 {id:5,name:"Name Tag Custom",desc:"Custom • 1 pcs",price:55000,cat:"custom",emoji:"✨",badge:"CUSTOM"},
 {id:6,name:"Moon Cat",desc:"Acrylic • Anime",price:45000,cat:"anime",emoji:"🐈‍⬛",badge:"NEW"},
 {id:7,name:"Cloud Bunny",desc:"PVC • Cute",price:36000,cat:"cute",emoji:"🐰",badge:""},
 {id:8,name:"Couple Set",desc:"Custom • 2 pcs",price:70000,cat:"custom",emoji:"💌",badge:"SET"}
];
let cart=[];
const rupiah=n=>new Intl.NumberFormat("id-ID",{style:"currency",currency:"IDR",maximumFractionDigits:0}).format(n);

function renderProducts(cat="all"){
 const list=cat==="all"?products:products.filter(p=>p.cat===cat);
 document.getElementById("products").innerHTML=list.map(p=>`
 <article class="product">
  <div class="product-img"><span>${p.emoji}</span>${p.badge?`<small class="badge">${p.badge}</small>`:""}</div>
  <div class="product-info"><h3>${p.name}</h3><p>${p.desc}</p>
   <div class="buy-row"><span class="price">${rupiah(p.price)}</span><button class="add" onclick="addToCart(${p.id})">+</button></div>
  </div>
 </article>`).join("");
}
function addToCart(id){const item=products.find(p=>p.id===id);cart.push(item);updateCart();openCart()}
function updateCart(){
 document.getElementById("cartCount").textContent=cart.length;
 document.getElementById("cartItems").innerHTML=cart.length?cart.map((p,i)=>`
 <div class="cart-item"><div class="cart-emoji">${p.emoji}</div><div class="cart-item-info"><b>${p.name}</b><small>${rupiah(p.price)}</small></div><button class="remove" onclick="removeItem(${i})">Hapus</button></div>`).join(""):"<p style='color:#777'>Keranjang masih kosong. Yuk pilih ganci favoritmu ✦</p>";
 document.getElementById("cartTotal").textContent=rupiah(cart.reduce((s,p)=>s+p.price,0));
}
function removeItem(i){cart.splice(i,1);updateCart()}
function openCart(){document.getElementById("cartModal").classList.add("open")}
function closeCart(){document.getElementById("cartModal").classList.remove("open")}
function checkout(){
 if(!cart.length)return alert("Keranjangmu masih kosong.");
 alert("Demo checkout: pesanan siap diproses! Hubungkan tombol ini ke WhatsApp/payment gateway saat website produksi.");
}
document.querySelectorAll(".filter").forEach(btn=>btn.addEventListener("click",()=>{
 document.querySelectorAll(".filter").forEach(b=>b.classList.remove("active"));btn.classList.add("active");renderProducts(btn.dataset.cat);
}));
renderProducts();updateCart();
