# GanciKu — Marketplace Gantungan Kunci

Landing page + katalog marketplace ganci yang siap di-host di GitHub Pages.

## Isi
- Hero section untuk menarik perhatian client
- Katalog produk responsif
- Filter kategori
- Keranjang belanja interaktif
- Demo checkout
- Responsive untuk HP dan desktop
- Tanpa framework/backend, sehingga mudah dipasang di GitHub Pages

## Cara upload ke GitHub
1. Buat repository baru, misalnya `ganciku`.
2. Upload `index.html`, `style.css`, `script.js`, dan `README.md`.
3. Buka **Settings → Pages**.
4. Pada **Build and deployment**, pilih **Deploy from a branch**.
5. Pilih branch `main` dan folder `/root`.
6. Simpan. GitHub akan memberikan alamat website.

## Catatan produksi
Data produk saat ini berada di `script.js`. Untuk website jual beli sungguhan, tahap berikutnya bisa ditambahkan:
- database produk,
- login seller/buyer,
- upload foto produk,
- checkout,
- pembayaran,
- WhatsApp order,
- dashboard penjual,
- pencarian dan stok.
